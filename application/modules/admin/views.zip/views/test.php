<?php foreach ($map as $k)
		{?>
		     <img style="height:100px;width:100px;" src="<?php echo base_url($dir)."/".$k;?>" alt="">
		   
		<?php }